import 'package:flutter/material.dart';
import 'package:sample2/core/app_export.dart';

class AppStyle {
  static TextStyle txtGilroySemiBold24 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtGilroyMedium14Black90002 = TextStyle(
    color: ColorConstant.black90002,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtGilroySemiBold16Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtGilroyMedium14Bluegray400 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtGilroyMedium10 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtSFProTextRegular15 = TextStyle(
    color: ColorConstant.gray80099,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'SF Pro Text',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtGilroyMedium14 = TextStyle(
    color: ColorConstant.blueA700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtGilroySemiBold18 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtSFProTextRegular11 = TextStyle(
    color: ColorConstant.black90001,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'SF Pro Text',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtGilroySemiBold16 = TextStyle(
    color: ColorConstant.black90002,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtGilroyMedium16 = TextStyle(
    color: ColorConstant.blueA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtGilroyMedium14Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Gilroy',
    fontWeight: FontWeight.w500,
  );
}
