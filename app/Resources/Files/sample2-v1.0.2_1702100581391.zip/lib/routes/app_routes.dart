import 'package:flutter/material.dart';
import 'package:sample2/presentation/job_listing_screen/job_listing_screen.dart';

class AppRoutes {
  static const String jobListingScreen = '/job_listing_screen';

  static Map<String, WidgetBuilder> routes = {
    jobListingScreen: (context) => JobListingScreen()
  };
}
