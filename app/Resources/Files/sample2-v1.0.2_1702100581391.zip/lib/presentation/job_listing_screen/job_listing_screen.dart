import '../job_listing_screen/widgets/listgoogle_item_widget.dart';
import '../job_listing_screen/widgets/listlock_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:sample2/core/app_export.dart';
import 'package:sample2/widgets/app_bar/custom_app_bar.dart';
import 'package:sample2/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class JobListingScreen extends StatelessWidget {
  TextEditingController inputFieldController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.gray50,
            resizeToAvoidBottomInset: false,
            appBar: CustomAppBar(
                height: getVerticalSize(55),
                leadingWidth: 40,
                leading: CustomImageView(
                    svgPath: ImageConstant.imgArrowleftBlueGray900,
                    height: getSize(24),
                    width: getSize(24),
                    margin: getMargin(left: 16, top: 13, bottom: 18),
                    onTap: () {
                      onTapImgArrowleft(context);
                    }),
                centerTitle: true,
                title: Text("Job Listing",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtGilroySemiBold24)),
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomSearchView(
                          focusNode: FocusNode(),
                          controller: inputFieldController,
                          hintText: "Search",
                          margin: getMargin(left: 16, top: 18, right: 16),
                          prefix: Container(
                              margin: getMargin(
                                  left: 12, top: 12, right: 8, bottom: 12),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgSearch)),
                          prefixConstraints:
                              BoxConstraints(maxHeight: getVerticalSize(44)),
                          suffix: Container(
                              margin: getMargin(
                                  left: 30, top: 12, right: 12, bottom: 12),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgMicrophone)),
                          suffixConstraints:
                              BoxConstraints(maxHeight: getVerticalSize(44))),
                      Padding(
                          padding: getPadding(left: 16, top: 27, right: 16),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Recent ",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtGilroySemiBold18),
                                Padding(
                                    padding: getPadding(bottom: 2),
                                    child: Text("See all",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtGilroyMedium16))
                              ])),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 16, top: 19, right: 45),
                              child: Row(children: [
                                Container(
                                    width: getHorizontalSize(100),
                                    padding: getPadding(
                                        left: 10, top: 4, right: 10, bottom: 4),
                                    decoration: AppDecoration.fillBlue50
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder8),
                                    child: Row(children: [
                                      Padding(
                                          padding: getPadding(top: 3),
                                          child: Text("Designer",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtGilroyMedium14)),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgClose18x18,
                                          height: getSize(18),
                                          width: getSize(18),
                                          margin: getMargin(
                                              left: 5, top: 1, bottom: 1))
                                    ])),
                                Container(
                                    width: getHorizontalSize(110),
                                    margin: getMargin(left: 8),
                                    padding: getPadding(
                                        left: 10, top: 5, right: 10, bottom: 5),
                                    decoration: AppDecoration.fillBlue50
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder8),
                                    child: Row(children: [
                                      Padding(
                                          padding: getPadding(top: 2),
                                          child: Text("Developer",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtGilroyMedium14)),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgClose18x18,
                                          height: getSize(18),
                                          width: getSize(18),
                                          margin: getMargin(left: 5))
                                    ])),
                                Container(
                                    width: getHorizontalSize(141),
                                    margin: getMargin(left: 8),
                                    padding: getPadding(
                                        left: 10, top: 5, right: 10, bottom: 5),
                                    decoration: AppDecoration.fillBlue50
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder8),
                                    child: Row(children: [
                                      Padding(
                                          padding: getPadding(top: 2),
                                          child: Text("Quality Analyst",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style:
                                                  AppStyle.txtGilroyMedium14)),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgClose18x18,
                                          height: getSize(18),
                                          width: getSize(18),
                                          margin: getMargin(left: 5))
                                    ]))
                              ]))),
                      Padding(
                          padding: getPadding(left: 16, top: 27, right: 16),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Recommended Jobs For You",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtGilroySemiBold18),
                                Padding(
                                    padding: getPadding(bottom: 2),
                                    child: Text("See all",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtGilroyMedium16))
                              ])),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                              height: getVerticalSize(231),
                              child: ListView.separated(
                                  padding: getPadding(left: 16, top: 19),
                                  scrollDirection: Axis.horizontal,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(
                                        height: getVerticalSize(16));
                                  },
                                  itemCount: 3,
                                  itemBuilder: (context, index) {
                                    return ListlockItemWidget();
                                  }))),
                      Padding(
                          padding: getPadding(left: 16, top: 27, right: 16),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("What’s New",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtGilroySemiBold18),
                                Padding(
                                    padding: getPadding(bottom: 2),
                                    child: Text("See all",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtGilroyMedium16))
                              ])),
                      Padding(
                          padding: getPadding(left: 16, top: 19, right: 16),
                          child: ListView.separated(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              separatorBuilder: (context, index) {
                                return Padding(
                                    padding:
                                        getPadding(top: 17.0, bottom: 17.0),
                                    child: SizedBox(
                                        width: getHorizontalSize(396),
                                        child: Divider(
                                            height: getVerticalSize(1),
                                            thickness: getVerticalSize(1),
                                            color: ColorConstant.blueGray100)));
                              },
                              itemCount: 3,
                              itemBuilder: (context, index) {
                                return ListgoogleItemWidget();
                              }))
                    ]))));
  }

  onTapImgArrowleft(BuildContext context) {
    Navigator.pop(context);
  }
}
