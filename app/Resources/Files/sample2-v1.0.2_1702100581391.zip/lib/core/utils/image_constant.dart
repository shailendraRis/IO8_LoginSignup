class ImageConstant {
  static String imgClose18x18 = 'assets/images/img_close_18x18.svg';

  static String imgLinkedin = 'assets/images/img_linkedin.svg';

  static String imgClose53x53 = 'assets/images/img_close_53x53.svg';

  static String imgSignal10x56 = 'assets/images/img_signal_10x56.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgCompanylogo = 'assets/images/img_companylogo.png';

  static String imgMicrophone = 'assets/images/img_microphone.svg';

  static String imgLock53x53 = 'assets/images/img_lock_53x53.svg';

  static String imgArrowleftBlueGray900 =
      'assets/images/img_arrowleft_blue_gray_900.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
